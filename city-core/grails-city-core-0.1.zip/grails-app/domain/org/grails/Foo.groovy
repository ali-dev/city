package org.grails

class Foo {

    static constraints = {
    }
}
