package ps.city.core

class Test {

    static constraints = {
    }
}
